// src/scrape-cli.js
// ─────────────────────────────────────────────────────────────
// CLI entry point — runs a single refresh cycle without
// starting the web server. Useful for testing.
//
// Usage: node src/scrape-cli.js
// ─────────────────────────────────────────────────────────────

const { runFullRefresh } = require('./scrapers/orchestrator');
const { ensureDirs } = require('./utils/storage');

async function main() {
  console.log('[cli] GoalScout — manual refresh');
  ensureDirs();

  const result = await runFullRefresh({ scrapeDetails: true });
  console.log('[cli] done:', JSON.stringify(result, null, 2));
}

main().catch(err => {
  console.error('[cli] fatal error:', err);
  process.exit(1);
});
